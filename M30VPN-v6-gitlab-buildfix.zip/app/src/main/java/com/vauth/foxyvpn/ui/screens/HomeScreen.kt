@file:OptIn(ExperimentalFoundationApi::class)
package com.vauth.foxyvpn.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.FoxyVpnApp
import com.vauth.foxyvpn.data.model.ConnectionState
import com.vauth.foxyvpn.ui.theme.ThemeController
import com.vauth.foxyvpn.ui.theme.ThemeMode
import com.vauth.foxyvpn.vpn.FoxyVpnService

private val M30Green = Color(0xFF21E66F)
private val M30NeonBlue = Color(0xFF00E5FF)
private val M30Dark = Color(0xFF07120D)
private val M30Panel = Color(0xFF0D2118)
private const val FIREFOX_SIGNUP_URL = "https://accounts.firefox.com/signup"
private const val MAZANDARAN_ZOOM_URL = "https://zoom.us/j/9558183803?pwd=VHpHWlNhdHk0SFQweDNZT1ZkR0pwZz09"

private fun openUrl(context: android.content.Context, url: String) {
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

private fun countryFlag(code: String): String {
    val c = code.trim().uppercase()
    if (c.length != 2 || c.any { it !in 'A'..'Z' }) return "🌐"
    return c.map { (0x1F1E6 + (it - 'A')).toChar() }.joinToString("")
}

private fun countryNameFa(code: String, fallback: String): String = when (code.uppercase()) {
    "US" -> "آمریکا"
    "CA" -> "کانادا"
    "GB" -> "انگلستان"
    "DE" -> "آلمان"
    "FR" -> "فرانسه"
    "NL" -> "هلند"
    "DK" -> "دانمارک"
    "SE" -> "سوئد"
    "NO" -> "نروژ"
    "FI" -> "فنلاند"
    "CH" -> "سوئیس"
    "AT" -> "اتریش"
    "BE" -> "بلژیک"
    "ES" -> "اسپانیا"
    "IT" -> "ایتالیا"
    "PT" -> "پرتغال"
    "IE" -> "ایرلند"
    "PL" -> "لهستان"
    "CZ" -> "جمهوری چک"
    "RO" -> "رومانی"
    "TR" -> "ترکیه"
    "AU" -> "استرالیا"
    "NZ" -> "نیوزیلند"
    "JP" -> "ژاپن"
    "SG" -> "سنگاپور"
    "IN" -> "هند"
    "BR" -> "برزیل"
    "MX" -> "مکزیک"
    else -> fallback.ifBlank { code }
}

@Composable
fun HomeScreen(
    app: FoxyVpnApp,
    themeController: ThemeController,
    onRequestConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onOpenServers: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val state by FoxyVpnService.state.collectAsState()
    val lastError by FoxyVpnService.lastError.collectAsState()
    val selectedProxy by app.proxyStateStore.selectedProxyFlow.collectAsState()
    val context = LocalContext.current

    val connected = state == ConnectionState.CONNECTED
    val green = if (connected) M30Green else MaterialTheme.colorScheme.primary
    val background = if (connected) M30Dark else MaterialTheme.colorScheme.background
    val panel = if (connected) M30Panel else MaterialTheme.colorScheme.surfaceContainerHigh
    val haptics = LocalHapticFeedback.current
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val mode = themeController.mode

    val animatedGreen by animateColorAsState(green, label = "m30-green")
    val scale by animateFloatAsState(
        targetValue = if (connected) 1f else 0.92f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "m30-power-scale",
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = background,
            topBar = {
                TopAppBar(
                    title = { Text("M30 VPN", fontWeight = FontWeight.Bold) },
                    actions = {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .combinedClickable(
                                    role = Role.Button,
                                    onClick = { themeController.toggle(systemDark) },
                                    onLongClick = {
                                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                        themeController.set(ThemeMode.SYSTEM)
                                    },
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = when (mode) {
                                    ThemeMode.SYSTEM -> Icons.Filled.BrightnessAuto
                                    ThemeMode.LIGHT -> Icons.Filled.LightMode
                                    ThemeMode.DARK -> Icons.Filled.DarkMode
                                },
                                contentDescription = "تغییر پوسته",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    },
                )
            },
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(background)
                    .padding(padding)
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .size(204.dp)
                        .clip(CircleShape)
                        .background(animatedGreen.copy(alpha = if (connected) 0.18f else 0.09f))
                        .border(3.dp, animatedGreen.copy(alpha = 0.65f), CircleShape)
                        .clickable {
                            if (state == ConnectionState.DISCONNECTED) onRequestConnect() else onDisconnect()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .size((158 * scale).dp)
                            .clip(CircleShape)
                            .background(animatedGreen.copy(alpha = if (connected) 0.34f else 0.15f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = if (connected) Icons.Filled.Shield else Icons.Filled.Power,
                            contentDescription = if (connected) "قطع اتصال" else "اتصال",
                            tint = if (connected) Color.White else animatedGreen,
                            modifier = Modifier.size(68.dp),
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text(
                    text = when (state) {
                        ConnectionState.CONNECTED -> "متصل است"
                        ConnectionState.CONNECTING -> "در حال اتصال…"
                        ConnectionState.DISCONNECTED -> "اتصال قطع است"
                    },
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (connected) M30Green else MaterialTheme.colorScheme.onBackground,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = when (state) {
                        ConnectionState.CONNECTED -> "اتصال شما امن و خصوصی است"
                        ConnectionState.CONNECTING -> "لطفاً چند لحظه صبر کنید"
                        ConnectionState.DISCONNECTED -> "برای اتصال، دکمه را لمس کنید"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Spacer(Modifier.height(14.dp))
                Card(
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenServers),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = panel),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = selectedProxy?.let { countryFlag(it.countryCode) } ?: "🌐",
                            style = MaterialTheme.typography.headlineMedium,
                        )
                        Spacer(Modifier.size(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("موقعیت اتصال", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                selectedProxy?.let { countryNameFa(it.countryCode, it.countryName) } ?: "انتخاب کشور",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                        Icon(Icons.Filled.Public, contentDescription = "انتخاب کشور", tint = if (connected) M30Green else MaterialTheme.colorScheme.primary)
                    }
                }

                if (connected) {
                    Spacer(Modifier.height(10.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = M30Panel),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                modifier = Modifier.size(42.dp).clip(CircleShape).background(M30Green.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.Check, contentDescription = null, tint = M30Green) }
                            Spacer(Modifier.size(10.dp))
                            Column {
                                Text("محافظت فعال است", fontWeight = FontWeight.Bold, color = M30Green)
                                Spacer(Modifier.height(1.dp))
                                Text("ترافیک اینترنت از تونل VPN عبور می‌کند", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                val error = lastError
                if (error != null && state != ConnectionState.CONNECTING) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { openUrl(context, MAZANDARAN_ZOOM_URL) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = M30NeonBlue,
                        contentColor = Color.Black,
                    ),
                ) {
                    Icon(Icons.Filled.VideoCall, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text("ورود به جلسه زوم مازندران", fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Card(
                        modifier = Modifier.weight(1f).clickable(onClick = onOpenServers),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = panel),
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Public, contentDescription = null)
                            Spacer(Modifier.height(3.dp))
                            Text("سرورها", fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f).clickable(onClick = onOpenSettings),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = panel),
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.Settings, contentDescription = null)
                            Spacer(Modifier.height(3.dp))
                            Text("تنظیمات", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { openUrl(context, FIREFOX_SIGNUP_URL) }.padding(vertical = 5.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Link, contentDescription = null, tint = M30NeonBlue, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(5.dp))
                    Text("ساخت حساب جدید", color = M30NeonBlue, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}
