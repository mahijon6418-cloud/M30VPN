# M30 VPN – customized source

Customized UI fork of FoxyVPN 1.0.4. The existing authentication and VPN service implementation is retained so the existing account/service flow remains intact.

Changes:
- App label: M30 VPN
- Application ID: com.m30.vpn
- Generic account wording in UI
- Country-only server picker with ISO flag
- Hostnames, IPs, ports, cities and ping details hidden from the server picker
- M30 launcher icon

Internal service-specific endpoints and identifiers remain unchanged because they are required for the existing service.

## M30 VPN v5 changes
- Redesigned connection screen with a cleaner compact layout.
- Added direct Firefox Account registration button.
- Added Mazandaran Zoom meeting button.
- Release build is configured for arm64-v8a only to reduce APK size.
- Added GitLab CI configuration in `.gitlab-ci.yml` for release builds.
