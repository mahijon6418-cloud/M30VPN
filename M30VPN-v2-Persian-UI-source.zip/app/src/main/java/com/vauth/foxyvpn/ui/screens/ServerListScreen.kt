package com.vauth.foxyvpn.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.vpn.PingUtil
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import com.vauth.foxyvpn.data.ProxyStateStore
import com.vauth.foxyvpn.data.RECOMMENDED_COUNTRY_CODE
import com.vauth.foxyvpn.data.ServerListClient
import com.vauth.foxyvpn.data.model.VpnCountry


private fun persianCountryName(code: String, fallback: String): String = when (code.trim().uppercase()) {
    "US" -> "آمریکا"
    "CA" -> "کانادا"
    "GB" -> "انگلستان"
    "DE" -> "آلمان"
    "FR" -> "فرانسه"
    "NL" -> "هلند"
    "DK" -> "دانمارک"
    "SE" -> "سوئد"
    "NO" -> "نروژ"
    "FI" -> "فنلاند"
    "CH" -> "سوئیس"
    "AT" -> "اتریش"
    "BE" -> "بلژیک"
    "ES" -> "اسپانیا"
    "IT" -> "ایتالیا"
    "PT" -> "پرتغال"
    "IE" -> "ایرلند"
    "PL" -> "لهستان"
    "CZ" -> "جمهوری چک"
    "RO" -> "رومانی"
    "TR" -> "ترکیه"
    "AU" -> "استرالیا"
    "NZ" -> "نیوزیلند"
    "JP" -> "ژاپن"
    "SG" -> "سنگاپور"
    "IN" -> "هند"
    "BR" -> "برزیل"
    "MX" -> "مکزیک"
    else -> fallback.ifBlank { code }
}

private fun flagForCountry(code: String): String {
    val normalized = code.trim().uppercase()
    if (normalized.length != 2 || normalized.any { it !in 'A'..'Z' }) return "🌐"
    return normalized.map { (0x1F1E6 + (it - 'A')).toChar() }.joinToString("")
}

@Composable
fun ServerListScreen(
    serverListClient: ServerListClient,
    proxyStateStore: ProxyStateStore,
    onServerSelected: () -> Unit,
    onBack: () -> Unit,
) {
    var countries by remember { mutableStateOf<List<VpnCountry>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pingByCountry by remember { mutableStateOf<Map<String, Int?>>(emptyMap()) }
    val selectedState by proxyStateStore.selectedProxyFlow.collectAsState()

    LaunchedEffect(Unit) {
        runCatching { serverListClient.fetchCountries() }
            .onSuccess { countries = it }
            .onFailure { errorMessage = it.message ?: "Failed to load locations" }
        isLoading = false
    }

    val ordered = remember(countries) {
        countries.sortedWith(compareBy({ it.code != RECOMMENDED_COUNTRY_CODE }, { it.name }))
    }

    // Measure the best TCP latency for each country while keeping server details hidden.
    LaunchedEffect(countries) {
        if (countries.isEmpty()) return@LaunchedEffect
        val results = coroutineScope {
            countries.map { country ->
                async {
                    val candidates = ServerListClient.candidatesForCountry(countries, country.code)
                    val pings = candidates.map { candidate ->
                        async { PingUtil.measureTcpLatencyMs(candidate.host, candidate.port) }
                    }.awaitAll().filterNotNull()
                    country.code to pings.minOrNull()
                }
            }.awaitAll().toMap()
        }
        pingByCountry = results
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("انتخاب کشور") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                errorMessage != null && countries.isEmpty() -> Text(
                    errorMessage.orEmpty(),
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                )
                else -> LazyColumn {
                    items(ordered, key = { it.code }) { country ->
                        val selected = selectedState?.countryCode == country.code
                        val ping = pingByCountry[country.code]
                        ListItem(
                            headlineContent = { Text(persianCountryName(country.code, country.name), fontWeight = FontWeight.SemiBold) },
                            supportingContent = {
                                Text(
                                    when {
                                        ping == null -> "پینگ: —"
                                        else -> "پینگ: ${ping} میلی‌ثانیه"
                                    }
                                )
                            },
                            leadingContent = { Text(flagForCountry(country.code)) },
                            trailingContent = {
                                if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "انتخاب‌شده")
                            },
                            modifier = Modifier
                                .clickable {
                                    val candidates = ServerListClient.candidatesForCountry(countries, country.code)
                                    val chosen = candidates.randomOrNull()
                                    if (chosen != null) {
                                        proxyStateStore.save(chosen)
                                        onServerSelected()
                                    } else {
                                        errorMessage = "سروری برای ${persianCountryName(country.code, country.name)} در دسترس نیست"
                                    }
                                }
                                .padding(horizontal = 8.dp),
                        )
                    }
                }
            }
        }
    }
}
